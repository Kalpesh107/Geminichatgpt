import React, { useState, useRef, useEffect } from "react";
import "./App.css";
import { IoSend } from "react-icons/io5";
import "bootstrap/dist/css/bootstrap.min.css";
import { API_KEY, BASE_URL } from "../Appconstant";
import axios from "axios";

const App = () => {
  // console.log(BASE_URL, "BASE_URL");
  // console.log(API_KEY, "API_KEY");
  const [prompt, setPrompt] = useState("");
  const [chat, setChat] = useState([
    // { sender: "hello" },
    // { response: "hello world" },
  ]);
  const messagesEndRef = useRef(null);

  const sendToGemini = () => {
    if (prompt.trim() === "") return;
    const updatedChat = [...chat, { sender: prompt }];
    setChat(updatedChat);
    axios
      .post(
        BASE_URL + "models/gemini-2.0-flash:generateContent?key=" + API_KEY,
        {
          contents: [
            {
              parts: [{ text: prompt }],
            },
          ],
        },
        {
          Headers: {
            "content-type": "application/json",
          },
        }
      )
      .then((response) => {
        console.log("🚀 ~ .then ~ response:", response);

        setChat((prevChat) => [
          ...prevChat,
          { response: response.data.candidates[0].content.parts[0].text },
        ]);
      });

    setPrompt("");

    // Simulated response
    setTimeout(() => {}, 500);
  };

  // Auto scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat]);

  return (
    <div className="container d-flex flex-column vh-100">
      {/* Chat Header */}
      <div className="py-3 text-center border-bottom bg-light">
        <h5>Chat with Decode</h5>
      </div>

      {/* Chat Messages */}
      <div
        className="flex-grow-1 overflow-auto p-3"
        style={{ background: "#f7f7f7" }}
      >
        {chat.map((c, index) => (
          <div
            key={index}
            className={`d-flex mb-2 ${
              c.sender ? "justify-content-end" : "justify-content-start"
            }`}
          >
            <div
              className={`p-2 rounded ${
                c.sender ? "bg-primary text-white" : "bg-secondary text-white"
              }`}
              style={{ maxWidth: "75%" }}
            >
              {c.sender || c.response}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="border-top p-3 bg-white d-flex align-items-center">
        <input
          type="text"
          className="form-control me-2"
          placeholder="Type your message..."
          onChange={(e) => setPrompt(e.target.value)}
          value={prompt}
          onKeyPress={(e) => e.key === "Enter" && sendToGemini()}
        />
        <button className="btn btn-primary" onClick={sendToGemini}>
          <IoSend size={20} />
        </button>
      </div>
    </div>
  );
};

export default App;
